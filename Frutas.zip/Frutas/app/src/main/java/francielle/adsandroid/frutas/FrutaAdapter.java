package francielle.adsandroid.frutas;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

class FrutaAdapter extends ArrayAdapter {

    int mResource;
    Context mContext;

    public FrutaAdapter(Context context, int resource, List objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    public View getView(int position, View convertiView, ViewGroup parent){
        LayoutInflater inflater = LayoutInflater.from(mContext);

        convertiView = inflater.inflate(mResource,parent,false);

        TextView tvCodigo = convertiView.findViewById(R.id.tvCodigo);
        TextView tvNome = convertiView.findViewById(R.id.tvNome);
        TextView tvPreco = convertiView.findViewById(R.id.tvPreco);
        TextView tvPrecoVenda = convertiView.findViewById(R.id.tvPrecoVenda);
        ImageView imagem = convertiView.findViewById(R.id.imageView);

        Fruta f = (Fruta)getItem(position);
        tvCodigo.setText(Integer.toString(f.getCodigo()));
        tvNome.setText(f.getNome());
        tvPreco.setText(String.valueOf(Math.round(f.getPreco().floatValue())));


        tvPrecoVenda.setText(String.valueOf(Math.round(f.getPreco_venda().floatValue())));

        imagem.setImageResource(f.getImagem());


        return convertiView;
    }
}
