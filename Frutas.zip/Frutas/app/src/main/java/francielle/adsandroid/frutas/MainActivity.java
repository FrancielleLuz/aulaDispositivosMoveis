package francielle.adsandroid.frutas;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    SQLiteDatabase bd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ArrayList<String> arrayString;

        //arrayString = new ArrayList<>();
        //arrayString.add("Maça");


        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(
        //      this,android.R.layout.simple_list_item_1,
        //    arrayString
        //);
        //1listView.setAdapter(adapter);

        bd = openOrCreateDatabase("banco", MODE_PRIVATE,null);

        bd.execSQL("CREATE TABLE IF NOT EXISTS alunos ( id INTEGER PRIMARY KEY AUTOINCREMENT, nome VARCHAR)" );
        bd.execSQL("INSERT INTO alunos (nome) VALUES ('Romulo Beninca')");
        bd.execSQL("INSERT INTO alunos (nome) VALUES ('Mateus Nunes')");
        bd.execSQL("INSERT INTO alunos (nome) VALUES ('Andreu Carminatti')");

        Cursor cursor = bd.rawQuery("SELECT id, nome FROM alunos ", null);
        cursor.moveToFirst();

        do {
            String s = cursor.getString( 1);
            Log.i(" Resultado Sql :",s );
        }while (cursor.moveToNext()) ;


        Frutas frutas = new Frutas();
        ArrayList<Fruta> listaFrutas = new ArrayList<>();

        for(Fruta f: frutas.FRUTAS){
            listaFrutas.add(f);
        }

        listView = findViewById(R.id.listView);

        FrutaAdapter adapter = new FrutaAdapter(
                getApplicationContext(),
                R.layout.lista_personalizada,
                listaFrutas
        );

        listView.setAdapter(adapter);
    }
}
