package francielle.adsandroid.imc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    EditText resultado, peso, altura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        peso =  this.findViewById(R.id.editPeso);
        altura =  this.findViewById(R.id.editAltura);
        resultado =  this.findViewById(R.id.editResultado);


        final Button btnCalcular = this.findViewById(R.id.buttonCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularImc(Double.parseDouble(peso.getText().toString()),Double.parseDouble(altura.getText().toString()));
            }
        });
    }


    public void calcularImc(double peso, double altura){

        double numSorteado = peso / (altura*altura);

        resultado.setText(String.valueOf(numSorteado));
    }
}
