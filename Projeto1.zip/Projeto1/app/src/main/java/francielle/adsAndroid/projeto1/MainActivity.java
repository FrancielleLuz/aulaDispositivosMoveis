package francielle.adsAndroid.projeto1;

import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.view.View.OnClickListener;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnLibra, btnDolar, btnEuro, btnHistorico;
    double libra=5.05, dolar=3.86, euro=4.33;
    private ArrayList<Historico> arrHist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLibra = (Button)findViewById(R.id.btnLibra);
        btnDolar = (Button)findViewById(R.id.btnDolar);
        btnEuro = (Button)findViewById(R.id.btnEuro);
        btnHistorico = (Button)findViewById(R.id.btnHistorico);

            btnLibra.setOnClickListener(new OnClickListener() {
               @Override

               public void onClick(View v) {

                   EditText text = (EditText)findViewById(R.id.TextValor);
                   double resultado = CalcularValor(Double.parseDouble(text.getText().toString()),libra);

                   //guardando informaçoes para proxima activity
                   Bundle bundle = new Bundle();
                   bundle.putString("resultado", String.valueOf(resultado));

                   DecimalFormat df = new DecimalFormat("###,##0.000");
                   Historico objH = new Historico();
                   objH.setDescricao(text.getText().toString()+" Reais, para "+String.valueOf(df.format(resultado))+" Libras");
                   arrHist.add(objH);

                   //chamando nova activity e enviando os dados guardados
                   Intent intent = new Intent(MainActivity.this, ResultadoActivity.class);
                   intent.putExtras(bundle);
                   startActivity(intent);

               }
            });



            btnDolar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    EditText text = (EditText)findViewById(R.id.TextValor);
                    double resultado = CalcularValor(Double.parseDouble(text.getText().toString()),dolar);

                    //guardando informaçoes para proxima activity
                    Bundle bundle = new Bundle();
                    bundle.putString("resultado", String.valueOf(resultado));

                    DecimalFormat df = new DecimalFormat("###,##0.000");
                    Historico objH = new Historico();
                    objH.setDescricao(text.getText().toString()+" Reais, para "+String.valueOf(df.format(resultado))+" Dolares");
                    arrHist.add(objH);

                    //chamando nova activity e enviando os dados guardados
                    Intent intent = new Intent(MainActivity.this, ResultadoActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);

                }
            });

            btnEuro.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    EditText text = (EditText)findViewById(R.id.TextValor);
                    double resultado = CalcularValor(Double.parseDouble(text.getText().toString()),euro);

                    //guardando informaçoes para proxima activity
                    Bundle bundle = new Bundle();
                    bundle.putString("resultado", String.valueOf(resultado));

                    DecimalFormat df = new DecimalFormat("###,##0.000");
                    Historico objH = new Historico();
                    objH.setDescricao(text.getText().toString()+" Reais, para "+String.valueOf(df.format(resultado))+" Euros");
                    arrHist.add(objH);

                    //chamando nova activity e enviando os dados guardados
                    Intent intent = new Intent(MainActivity.this, ResultadoActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);

                }
            });

            btnHistorico.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    EditText text = (EditText)findViewById(R.id.TextValor);
                    double resultado = CalcularValor(Double.parseDouble(text.getText().toString()),euro);

                    //chamando nova activity e enviando os dados guardados
                    Intent intent = new Intent(MainActivity.this, HistoricoActivity.class);
                    intent.putExtra("Array", arrHist);
                    startActivity(intent);
                }
            });


    }

    public Double CalcularValor(double valorInicio,double moeda){

        double valorTotal=0;

        valorTotal = valorInicio / moeda;

        return valorTotal;
    }
}
