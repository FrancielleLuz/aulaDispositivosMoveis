package francielle.adsAndroid.projeto1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.ScrollView;

import java.util.ArrayList;

public class HistoricoActivity extends AppCompatActivity {

    ScrollView scroll;
    ListView listV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico);

        scroll = (ScrollView)findViewById(R.id.scroll);
        listV = (ListView)findViewById(R.id.view);

        ArrayList<Historico> arr;
        arr = (ArrayList<Historico>) getIntent().getSerializableExtra("Array");

        ArrayAdapter<Historico> adapter = new ArrayAdapter<Historico>(this,android.R.layout.simple_list_item_1, arr);

        listV.setAdapter(adapter);
    }
}
