package francielle.adsAndroid.projeto1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.Locale;

public class ResultadoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado);

        //carregando dados da activity anterior
        Intent intent = getIntent();
        Bundle dados = intent.getExtras();
        //String resultado = dados.getString("resultado");
        double resultado = Double.parseDouble(dados.getString("resultado"));

        DecimalFormat df = new DecimalFormat("###,##0.000");

        TextView text = (TextView)findViewById(R.id.textView3);
        text.setText(df.format(resultado));

    }
}
