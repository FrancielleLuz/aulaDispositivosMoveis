package francielle.adsAndroid.projeto1;

import java.io.Serializable;

public class Historico implements Serializable {

    private String descricao;

    public Historico(){

    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "Conversão: " + descricao;
    }

}
