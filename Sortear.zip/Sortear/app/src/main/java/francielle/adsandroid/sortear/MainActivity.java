package francielle.adsandroid.sortear;

import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText resultado, numero1, numero2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numero1 =  this.findViewById(R.id.editNumero1);
        numero2 =  this.findViewById(R.id.editNumero2);
        resultado =  this.findViewById(R.id.editresultado);


        final Button btnSortear = this.findViewById(R.id.buttonSortear);

        btnSortear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               sotearNumero(Integer.parseInt(numero1.getText().toString()),Integer.parseInt(numero2.getText().toString()));
            }
        });

    }



    public void sotearNumero(int num1, int num2){
        Random random = new Random();

        int numSorteado = random.nextInt((num2 - num1) + 1) + num1;

        resultado.setText(String.valueOf(numSorteado));
    }
}
