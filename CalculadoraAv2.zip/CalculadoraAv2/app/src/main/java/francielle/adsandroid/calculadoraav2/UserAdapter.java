package francielle.adsandroid.calculadoraav2;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class UserAdapter extends ArrayAdapter<ObjAdapter> {

    private final ArrayList<ObjAdapter> itens;
    private Context _context;
    int _layoutId;
    Activity _act;

    public UserAdapter(Context context, int layoutId, ArrayList<ObjAdapter> itens, Activity act) {
        super(context, layoutId, itens);
        _context = context;
        _layoutId = layoutId;
        _act = act;
        this.itens = itens;
    }

    @Override
    public int getCount() {
        return itens.size();
    }

    @Override
    public ObjAdapter getItem(int position) {
        return itens.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {

        view = _act.getLayoutInflater().inflate(R.layout.adapter_personalizado, parent, false);

        ObjAdapter item = getItem(position);

        int parcela = item.getNumeroParcela();
        double valor = item.getValor();

        TextView numeroParcelaView = (TextView) view.findViewById(R.id.textViewParcela);
        TextView valorView = (TextView) view.findViewById(R.id.textViewValor);

        numeroParcelaView.setText(String.valueOf(parcela));
        valorView.setText(String.valueOf(valor));

        return view;
    }

}
