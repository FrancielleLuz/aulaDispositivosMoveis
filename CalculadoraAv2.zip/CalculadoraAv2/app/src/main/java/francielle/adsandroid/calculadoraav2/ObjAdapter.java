package francielle.adsandroid.calculadoraav2;

public class ObjAdapter {

    int numeroParcela;
    double valor;

    public ObjAdapter(int _nrParcela, double _valor){
        this.numeroParcela = _nrParcela;
        this.valor = _valor;
    }

    public int getNumeroParcela() {
        return numeroParcela;
    }

    public void setNumeroParcela(int numeroParcela) {
        this.numeroParcela = numeroParcela;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
}
