package francielle.adsandroid.calculadoraav2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaParcelas extends AppCompatActivity {

    SQLiteDatabase bd;
    ListView lista;
    ObjAdapter adapterObj;
    ArrayList<ObjAdapter> listaAdapter;
    UserAdapter view;
    Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_parcelas);

        btnSalvar = findViewById(R.id.btnSalvar);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarParcela();
            }
        });

        lista = (ListView) findViewById(R.id.listaParcelas);

        carregaLista();
    }

    public void carregaLista(){
        Bundle bundle = getIntent().getExtras();

        double valor = bundle.getDouble("valor");
        double taxaJuros = bundle.getDouble("taxajuros");
        int parcela = bundle.getInt("parcela");

        double valorFinal = calculaValorParcela(valor, taxaJuros, parcela);

        listaAdapter = new ArrayList<>();

        for (int i = 1; i <= parcela; i++){
            adapterObj = new ObjAdapter(i, valorFinal);
            listaAdapter.add(adapterObj);
        }

        view = new UserAdapter(this,1,listaAdapter, this);

        lista.setAdapter(view);
    }

    public void salvarParcela(){
        bd = openOrCreateDatabase("banco", MODE_PRIVATE,null);

        bd.execSQL("CREATE TABLE IF NOT EXISTS valores ( id INTEGER PRIMARY KEY AUTOINCREMENT, parcela INTEGER, valor REAL )" );

        deletaRegistros();

        //ver essa condição
        for (int i = 0; i < listaAdapter.size(); i++){
            insereDado(listaAdapter.get(i).getNumeroParcela(), listaAdapter.get(i).getValor());
        }

        Intent intent = new Intent();
        setResult(1, intent);
        super.finish();
    }

    public Long insereDado(int parc, double vlr){
        ContentValues valores;
        Long resultado;

        //db = banco.getWritableDatabase();
        valores = new ContentValues();
        valores.put("parcela", parc);
        valores.put("valor", vlr);

        resultado = bd.insert("valores", null, valores);

        return resultado;
    }

    public void deletaRegistros(){
        bd.execSQL("DELETE FROM valores" );
    }

    public double calculaValorParcela(double vlr, double txJuros, int qtdParcela){
        double resultado = 0;
        double parc = Double.parseDouble(String.valueOf(qtdParcela));

        //resultado = vlr * (txJuros / (1 - Math.pow( (1+txJuros),(qtdParcela * (-1) ) ) ) );
        resultado =  (vlr * txJuros) / (1.0 - (1.0 / (Math.pow(1.0+txJuros,parc))));

        resultado = resultado / qtdParcela;
        return Math.round(resultado);
    }
}
