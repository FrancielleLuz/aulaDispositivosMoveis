package francielle.adsandroid.calculadoraav2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button buttoncalcular;
    EditText editValor, editTaxa, editParcela;
    double Resultado, Valor, TaxaJuros;
    ListView lista;
    ObjAdapter adapterObj;
    ArrayList<ObjAdapter> listaAdapter;
    UserAdapter view;
    int Parcela;

    ListView listView;

    public SQLiteDatabase bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bd = openOrCreateDatabase("banco", MODE_PRIVATE,null);

        lista = (ListView) findViewById(R.id.listMain);
        editValor = findViewById(R.id.txtValor);
        editTaxa = findViewById(R.id.txtTaxa);
        editParcela = findViewById(R.id.txtParcela);
        buttoncalcular = findViewById(R.id.btnCalcular);

        buttoncalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirNovaTela();
            }
        });

        deletaRegistros();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == 1){
            carregaParcela();
        }
    }

    public void abrirNovaTela(){
        Parcela = Integer.parseInt(editParcela.getText().toString());
        TaxaJuros = Double.parseDouble(editTaxa.getText().toString());
        Valor = Double.parseDouble(editValor.getText().toString());

        Intent intent = new Intent(this, ListaParcelas.class);
        intent.putExtra("parcela", Parcela);
        intent.putExtra("taxajuros", TaxaJuros);
        intent.putExtra("valor", Valor);
        startActivityForResult(intent, 1);
    }

    public void deletaRegistros(){
        bd.execSQL("DELETE FROM valores" );
    }

    public void carregaParcela(){
        listaAdapter = new ArrayList<>();
        Cursor cursor = bd.rawQuery("SELECT parcela, valor FROM valores ", null);
        cursor.moveToFirst();

        do {
            int parc = cursor.getInt(cursor.getColumnIndexOrThrow("parcela"));
            double vlr = cursor.getDouble(cursor.getColumnIndexOrThrow("valor"));

            adapterObj = new ObjAdapter(parc, vlr);
            listaAdapter.add(adapterObj);
        }while (cursor.moveToNext()) ;

        view = new UserAdapter(this,1,listaAdapter, this);

        lista.setAdapter(view);
    }
}
