package francielle.adsandroid.nota;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

public class Notas {

    SharedPreferences notas;
    SharedPreferences.Editor editor;
    Context context;

    private static final String PREFERENCIAS_FILE="Notes";

    public Notas(Context context) {
        this.context = context;
        notas = this.context.getSharedPreferences(PREFERENCIAS_FILE,Context.MODE_PRIVATE);
        editor = notas.edit();


    }

    public String recuperaNota(){
        if (this.notas.contains("nota")){
            String s=context.getResources().getString(R.string.nota_recuperada);
            Toast.makeText(this.context, s,Toast.LENGTH_LONG).show();
            return this.notas.getString("nota","");
        } else{
            return "";
        }
    }

    public String recuperaNota(){
        if (this.notas.contains("nota")){
            String s= context.getResources().getString(R.string.nota_recuperada);
            Toast.makeText(context,s,Toast.LENGTH_LONG).show();
            return this.notas.getString("nota","");
        } else{
            return "";
        }
    }
    
}


